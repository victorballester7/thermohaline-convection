# DEFAULTS
X_LABEL = 'x'
Y_LABEL = 'y'
FONTSIZE_TIME = 10
y_pos_text = 1.03
y_pos_title = y_pos_text + 0.14
colorbar_args = {'shrink': 0.5, 'aspect': 10, 'location': 'left'}
duration = 10  # duration of the animation in seconds
cols_removed_beginning = 0
cols_removed_end = 0
color_object = 'grey'
